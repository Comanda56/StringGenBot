-const settings = {
  packname: 'MeZo',
  author: '‎',
  botName: ".⤹3mk MeZo⤾.",
  botOwner: 'BoT MeZo', // Your name
  ownerNumber: '201050809147', //Set your number here without + symbol, just add country code & number without any space
  sessionId: 'KnightBot!H4sIAAAAAAAAA5VU25KiSBD9l3rFmAZFASM6YhERaFrFQbxtzENBFVjcKUoQJ/yFif29+ZsNuqen52F3tveJoi4nT+Y5mV9BXpAa27gD06+gpKSBDPdL1pUYTMHsEoaYggFAkEEwBbK+nDWB1FGRGpkwL4owCbGqJYZ3dbNARek83phpQ+a59QjuA1Be/JQEvwG0uaZpV0EZn4MoVJqzVMUcOvvGdu1Xpl/Nstb1DzbWN3v5Edx7REgoySO9POMMU5jauHMgoR+jv7T9btZwXBQHRdvw6DmzdkMhtKNTeMMax1VZgsS0iyrP+xj9alOv+bW6WW7pQm2V8erkS/wDOu0C2RAP3H7iYu/SzI21rr/Sr0mUY2QhnDPCug/XvTKdsSPh5bbDuap2rXPFQStM7KfQfjZ9NkwunRu0zg2nwceIHzbhYu+djeXkrO8ykub17LTfylrtrnYQ1Zbj8T66rcfqqPiVuEPfvJL8n7oXyyAUfdHUz/S0Vduj13HaZJiFnpKfDgQaBWcmnuOuK+GD9HOFNZ4yP25vFxL6kzpLnxdktx/uDn4a3UzxIZVs97DawnP9Th+yC/0dS/1pFO+0sXMrDrbBc97t7DbtERti61ATJ6eoGO+ty1O+YrgxydO6KQ5XiyIhHhmH60PAcrgf3zJnn6IuTDXHtXhbmG0eXzJKcGchMBXuA0BxRGpGISNF3u/JkwGAqHFxQDF7qS5Y+E0Xc3U5i+eVCJNZFz8fW0/l0qiL0+RhNFoeN8HtRulKfQQDUNIiwHWNkUlqVtBuiesaRrgG0z+/DECOr+xVtz7aSBiAkNCaefmlTAuI3kR9O4RBUFxy5nZ5oPULTMGUf9/GjJE8qvsyXnJIgzNpsHaGrAbTEKY1/pkgphiBKaMX/LNptQL1dd+OT/Z29LwEA5C96EEQmIIhL/BjXuYVQZSmQ/6P+lPbw8Ky/JRjBgYgh/1tsPz+7ftf+Pu3U/8twACkr88FaSQOZUkaKZIgyj1Cf3D/ybwPhDCDJK3BFGjLh3ZUJAt96fKScjQMVY9ULVLBe6ZvjnmVZIPstWrleii4O0p0HvoiMjtaygc91sJJp3KBb4zMODvoj/8A0o86fXgch8pB4Nax0iW2u0TW+rkqES3OQ99SNMRxJIy9lWxPZDzyPqNtvBOv1iSnIqbd8TpR5oxIdZWq4mrhV7LdhPPosY+GcEMC/GuwbfqASHrwjobaakK4kyRhzlgkDK9SuSa66xlzR+VktAvGVZq5M0VW8AUuOSvjCn+3+mxPKq1yK5FHhTrXZ36WwPjNyy+9lP6YYeTFZr2G/W9I8MtI+KHVf2r6Sry3Hn8f/ILxY8j8S6POPNONI+3paipeCsXzysg487NcTcLF1Wpzro6c3LiyqzhOr+B+/zIAZQpZWNAMTEGd+RAMAC0uvZGtPCx+E0lTE0uPonmfdgprpr43x5ZkuGYwK8FUkJShpIyEyfD+N4GGxuVRBwAA ',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.4",
  updateZipUrl: "https://github.com/mruniquehacker/Knightbot-MD/archive/refs/heads/main.zip",
};

module.exports = settings;
